Masao Free has only unaccented capital letters, numbers and punctuation. It has no OpenType features.	 
 	 
Masao Free is free for personal and commercial use. You may not sell this font or distribute a modified version of Masao. 

https://jonathanpaterson.ca/